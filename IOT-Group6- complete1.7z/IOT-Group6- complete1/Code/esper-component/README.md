# esper-demo
Project to demonstrate how to use [Esper](http://www.espertech.com/esper/) in Java.

Some files in [src/main/resources](src/main/resources) have been downloaded from [Yahoo! Finance](http://finance.yahoo.com/).
