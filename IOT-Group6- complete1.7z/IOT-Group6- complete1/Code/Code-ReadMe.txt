Esper engine:

The devised code is simple in regards to its functionality. To run the code, all the user has to do is press compile and Eclipse will take care of the rest.
The console will display characteristics of any users currently running our software, however, the resulting values (MAC addresses) will be stored on a text file called "Alerts.log"
Keep in mind that specifics like file-paths have been configured for our implementation, so, some changes may be necessary. 

Web interface: 

Website login:
User: 		admin
Password:	password

Email login:
User:		uoit2016iot@outlook.com
Password:	Uoit2016

Sending an email 

This is the most important part of the system as an email can notify the IT staff about any offenders (high bandwidth usage). There are two options:
One, send an email immediately. Should the IT staff be needed quickly (due to a large issue), they can be notififed immmediately by pressing the "email now" option. 
Two, an email is sent automatically at day's end. This option allows the IT staff to receive the entire list of offending users at the end of the day.


For more details please refer to the source code. 

Contact info:
Danish Shaikh	danish.shaikh@uoit.net
